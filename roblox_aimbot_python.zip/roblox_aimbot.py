"""
Roblox External + AI Aimbot
python roblox_aimbot.py
Missing packages: console will ask before installing.
"""

import ctypes
import struct
import time
import sys
import math
import re
import threading
import subprocess


def _ensure_deps():
    """Detect missing packages, ask in console, then pip install."""
    need = []
    try:
        import pymem  # noqa: F401
        import pymem.process  # noqa: F401
    except ImportError:
        need.append("pymem")
    try:
        import win32api  # noqa: F401
        import win32con  # noqa: F401
        import win32gui  # noqa: F401
    except ImportError:
        need.append("pywin32")
    try:
        import customtkinter  # noqa: F401
    except ImportError:
        need.append("customtkinter")

    if not need:
        return

    print()
    print("=" * 50)
    print("  SHIV — missing packages")
    print("=" * 50)
    print("  need:", ", ".join(need))
    print()
    print("  Install now with pip?")
    print("  [Y] yes   [N] quit")
    print("=" * 50)
    try:
        ans = input("  > ").strip().lower()
    except Exception:
        ans = "n"
    if ans not in ("y", "yes"):
        print("  skipped. install manually:")
        print("  python -m pip install " + " ".join(need))
        sys.exit(1)

    cmd = [sys.executable, "-m", "pip", "install", "--upgrade", *need]
    print()
    print("  running:", " ".join(cmd))
    print()
    try:
        r = subprocess.run(cmd, check=False)
        if r.returncode != 0:
            print("[!] pip failed (code %s). try as admin / check python." % r.returncode)
            sys.exit(1)
    except Exception as e:
        print("[!] install error:", e)
        sys.exit(1)

    print()
    print("  installed. starting...")
    print()
    # re-exec so imports see new packages
    try:
        os_exec = getattr(__import__("os"), "execv")
        os_exec(sys.executable, [sys.executable] + sys.argv)
    except Exception:
        pass


_ensure_deps()

try:
    import pymem
    import pymem.process
except ImportError:
    print("[!] pymem still missing after install")
    sys.exit(1)

try:
    import win32api
    import win32con
    import win32gui
except ImportError:
    print("[!] pywin32 still missing — may need: python -m pip install pywin32")
    print("    then run: python Scripts/pywin32_postinstall.py -install")
    sys.exit(1)

try:
    import customtkinter as ctk
except ImportError:
    print("[!] customtkinter still missing")
    sys.exit(1)

# ---------------------------------------------------------------------------
# Offsets — version-cec3ad5889b447cf
# ---------------------------------------------------------------------------
class Offsets:
    # pointers (version-cec3ad5889b447cf family + alternates)
    VisualEnginePointer        = 0x8656E40
    FakeDataModelPointer       = 0x8BCFD50
    FakeDataModelToDataModel   = 0x1F8
    VisualEngine_ViewMatrix    = 0x1B0
    VisualEngine_Dimensions    = 0xB10
    VisualEngine_FakeDataModel = 0xAF0

    NameContainer   = 0x70
    ChildrenStart   = 0x78
    ChildrenStartAlts = (0x78, 0x80, 0x70, 0x68)
    ChildrenEnd     = 0x8
    Parent          = 0x68
    ClassDescriptor = 0x18
    ClassName       = 0x8

    LocalPlayer     = 0x120
    LocalPlayerAlts = (0x120, 0x130, 0x118, 0x128)
    ModelInstance   = 0x288
    ModelInstanceAlts = (0x288, 0x380, 0x3A8, 0x330, 0x340, 0x350, 0x298, 0x2A0)
    DisplayName     = 0x128

    Health          = 0x180
    MaxHealth       = 0x198
    HumanoidRootPart= 0x460

    Primitive       = 0x178
    PrimitiveAlts   = (0x178, 0x148, 0x170, 0x180, 0x190, 0x160)
    Position        = 0xD4
    PositionAlts    = (0xD4, 0xEC, 0xE0, 0xC0, 0xC8, 0xF0, 0x100, 0x140)
    AssemblyLinearVelocity = 0xE0
    AssemblyLinearVelocityAlts = (0xE0, 0xEC, 0xF0, 0x14C, 0x150, 0x158)

    StringLength    = 0x10



class Auth:
    logged_in = False
    username  = ""
    keys_enabled = True
    KEYS = {
        "*": "123",
        "doigie": "123",
    }
    VALID_KEY = "123"
    APP_VERSION = "1.4.0"
    UPDATE_VERSION_URL = ""
    UPDATE_ZIP_URL = ""

    @classmethod
    def check(cls, user, key):
        try:
            if not getattr(cls, "keys_enabled", True):
                return True
            u = (user or "").strip().lower()
            k = (key or "").strip()
            if not k:
                return False
            # shared key works for any username
            if k == "123" or k == getattr(cls, "VALID_KEY", "123"):
                return True
            keys = getattr(cls, "KEYS", {}) or {}
            if u and keys.get(u) == k:
                return True
            if keys.get("*") == k:
                return True
            return False
        except Exception:
            return (key or "").strip() == "123"

class Profiles:
    """Per-game profiles. Rivals first — tune FOV/smooth/hit for that title."""
    active = "Rivals"
    data = {
        "Rivals": {
            "fov": 280.0,
            "smoothness": 10.0,
            "sensitivity": 1.1,
            "pull_strength": 1.4,
            "prediction": True,
            "prediction_str": 1.05,
            "hit_part": "Head",
            "sticky": True,
            "max_distance": 1800.0,
            "esp_max_dist": 1600.0,
            "ai_score": True,
            "notes": "Rivals profile — tighter gunplay, stronger prediction",
        },
        "Universal": {
            "fov": 180.0,
            "smoothness": 5.0,
            "sensitivity": 1.0,
            "pull_strength": 1.0,
            "prediction": False,
            "prediction_str": 0.7,
            "hit_part": "Head",
            "sticky": True,
            "max_distance": 2000.0,
            "esp_max_dist": 1500.0,
            "ai_score": False,
            "notes": "Generic defaults",
        },
        "Arsenal": {
            "fov": 160.0,
            "smoothness": 4.5,
            "sensitivity": 1.0,
            "pull_strength": 1.1,
            "prediction": True,
            "prediction_str": 0.85,
            "hit_part": "Head",
            "sticky": True,
            "max_distance": 1500.0,
            "esp_max_dist": 1400.0,
            "ai_score": True,
            "notes": "Arsenal profile",
        },
        "Da Hood": {
            "fov": 140.0,
            "smoothness": 5.5,
            "sensitivity": 0.95,
            "pull_strength": 1.0,
            "prediction": True,
            "prediction_str": 1.1,
            "hit_part": "Head",
            "sticky": True,
            "max_distance": 1200.0,
            "esp_max_dist": 1200.0,
            "ai_score": True,
            "notes": "Da Hood profile",
        },
    }

    @classmethod
    def apply(cls, name: str):
        prof = cls.data.get(name)
        if not prof:
            return
        cls.active = name
        Cfg.fov = float(prof["fov"])
        Cfg.smoothness = float(prof["smoothness"])
        Cfg.sensitivity = float(prof["sensitivity"])
        Cfg.pull_strength = float(prof["pull_strength"])
        Cfg.prediction = bool(prof["prediction"])
        Cfg.prediction_str = float(prof["prediction_str"])
        Cfg.hit_part = str(prof["hit_part"])
        Cfg.sticky = bool(prof["sticky"])
        Cfg.max_distance = float(prof["max_distance"])
        Cfg.esp_max_dist = float(prof["esp_max_dist"])
        Cfg.ai_score = bool(prof["ai_score"])

class Cfg:
    enabled         = True
    prediction      = False
    always_on       = False
    sticky          = False
    team_check      = False
    health_check    = False
    ai_score        = False
    fov             = 280.0
    smoothness      = 10.0  # high-rate constant velocity
    max_distance    = 2000.0
    prediction_str  = 0.9
    aim_key         = win32con.VK_RBUTTON  # hold RMB to lock until release
    sensitivity     = 1.0
    pull_strength   = 1.4
    hit_part        = "Head"
    triggerbot      = False
    autokill        = False
    autokill_delay  = 0.04
    trigger_delay   = 0.05
    trigger_key     = win32con.VK_XBUTTON2
    loop_ms         = 4
    esp_enabled     = False  # user toggles; boxes/names default on when enabled
    esp_box         = True
    esp_name        = True
    esp_health      = True
    esp_snap        = False
    esp_max_dist    = 1500.0
    accent          = "#a78bfa"

# default profile
Profiles.apply("Rivals")

class Status:
    attached = False
    players  = 0
    target   = "-"
    base     = 0
    message  = "Waiting for Roblox..."
    running  = True
    debug    = ""
    ban_score = 0.0          # 0 safe .. 100 hot
    ban_label = "LOW"
    snaps     = 0
    aim_time  = 0.0
    esp_list  = []
    locked    = False
    lock_name = "-"
    lock_dist = 0.0

def v3_sub(a, b): return (a[0]-b[0], a[1]-b[1], a[2]-b[2])
def v3_add(a, b): return (a[0]+b[0], a[1]+b[1], a[2]+b[2])
def v3_mul(a, s): return (a[0]*s, a[1]*s, a[2]*s)
def v3_len(a):    return math.sqrt(a[0]**2 + a[1]**2 + a[2]**2)
def v2_dist(a, b): return math.sqrt((a[0]-b[0])**2 + (a[1]-b[1])**2)

def world_to_screen(world, matrix, sw, sh):
    """Project world pos with two matrix conventions; return (sx,sy) or None."""
    if not matrix:
        return None
    wx, wy, wz = world

    def ndc_ok(x, y, w):
        if w <= 0.001:
            return None
        inv = 1.0 / w
        x *= inv
        y *= inv
        if abs(x) > 2.5 or abs(y) > 2.5:
            return None
        sx = (sw * 0.5) * (1.0 + x)
        sy = (sh * 0.5) * (1.0 - y)
        return (sx, sy)

    # row-major style
    x = wx*matrix[0] + wy*matrix[1] + wz*matrix[2] + matrix[3]
    y = wx*matrix[4] + wy*matrix[5] + wz*matrix[6] + matrix[7]
    w = wx*matrix[12] + wy*matrix[13] + wz*matrix[14] + matrix[15]
    r = ndc_ok(x, y, w)
    if r:
        return r

    # column-vector style
    x = wx*matrix[0] + wy*matrix[4] + wz*matrix[8] + matrix[12]
    y = wx*matrix[1] + wy*matrix[5] + wz*matrix[9] + matrix[13]
    w = wx*matrix[3] + wy*matrix[7] + wz*matrix[11] + matrix[15]
    return ndc_ok(x, y, w)


user32 = ctypes.windll.user32

class MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ("dx", ctypes.c_long),
        ("dy", ctypes.c_long),
        ("mouseData", ctypes.c_ulong),
        ("dwFlags", ctypes.c_ulong),
        ("time", ctypes.c_ulong),
        ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)),
    ]

class INPUT_I(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT)]

class INPUT(ctypes.Structure):
    _fields_ = [("type", ctypes.c_ulong), ("ii", INPUT_I)]

def move_mouse(dx, dy):
    dx, dy = int(dx), int(dy)
    if dx == 0 and dy == 0:
        return
    inp = INPUT()
    inp.type = 0
    inp.ii.mi.dx = dx
    inp.ii.mi.dy = dy
    inp.ii.mi.dwFlags = 0x0001
    if user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT)) != 1:
        user32.mouse_event(0x0001, dx, dy, 0, 0)

def is_key_down(vk):
    return bool(user32.GetAsyncKeyState(vk) & 0x8000)

def was_key_pressed(vk, prev):
    down = is_key_down(vk)
    pressed = down and not prev.get(vk, False)
    prev[vk] = down
    return pressed


# ---------------------------------------------------------------------------
# FOV overlay (transparent topmost canvas)
# ---------------------------------------------------------------------------
import tkinter as tk

class FovOverlay:
    def __init__(self):
        self.root = None
        self.canvas = None
        self.enabled = False
        self._sw = 800
        self._sh = 600
        self._x = 0
        self._y = 0

    def _roblox_rect(self):
        try:
            hwnd = win32gui.FindWindow(None, "Roblox")
            if not hwnd:
                found = []
                def _e(h, res):
                    t = win32gui.GetWindowText(h)
                    if "Roblox" in t and win32gui.IsWindowVisible(h):
                        res.append(h)
                win32gui.EnumWindows(_e, found)
                hwnd = found[0] if found else None
            if not hwnd:
                return None
            left, top, right, bottom = win32gui.GetClientRect(hwnd)
            # client to screen
            pt = win32gui.ClientToScreen(hwnd, (0, 0))
            w, h = right - left, bottom - top
            if w < 100 or h < 100:
                return None
            return pt[0], pt[1], w, h
        except Exception:
            return None

    def ensure(self, x, y, sw, sh):
        if self.root is None:
            self.root = tk.Tk()
            self.root.overrideredirect(True)
            self.root.attributes("-topmost", True)
            try:
                self.root.attributes("-transparentcolor", "black")
            except Exception:
                pass
            self.root.config(bg="black")
            self.canvas = tk.Canvas(self.root, bg="black", highlightthickness=0, bd=0)
            self.canvas.pack(fill="both", expand=True)
            try:
                hwnd = self.root.winfo_id()
                styles = ctypes.windll.user32.GetWindowLongW(hwnd, -20)
                ctypes.windll.user32.SetWindowLongW(hwnd, -20, styles | 0x80000 | 0x20)
            except Exception:
                pass
        if (sw, sh, x, y) != (self._sw, self._sh, self._x, self._y):
            self._sw, self._sh, self._x, self._y = sw, sh, x, y
            self.root.geometry(f"{sw}x{sh}+{x}+{y}")

    def update(self, sw, sh, fov, target_scr=None, esp_list=None):
        if not self.enabled and not getattr(Cfg, "esp_enabled", False) and not getattr(Cfg, "draw_fov", False):
            return
        # ESP alone still needs the transparent window
        if getattr(Cfg, "esp_enabled", False):
            self.enabled = True
        rect = self._roblox_rect()
        if rect:
            x, y, sw, sh = rect
        else:
            x, y = 0, 0
            sw, sh = int(sw), int(sh)
        self.ensure(x, y, int(sw), int(sh))
        self.canvas.delete("all")
        cx, cy = sw // 2, sh // 2

        if Cfg.esp_enabled and esp_list:
            for e in esp_list:
                sx, sy = e["scr"]
                if sx != sx or sy != sy:
                    continue
                if sx < -80 or sy < -80 or sx > sw + 80 or sy > sh + 80:
                    continue
                scale = max(10, min(56, 1000.0 / max(50.0, e.get("dist", 120.0))))
                x1, y1 = int(sx - scale * 0.5), int(sy - scale * 1.7)
                x2, y2 = int(sx + scale * 0.5), int(sy + scale * 0.35)
                col = "#c4b5fd"
                if Cfg.esp_box:
                    self.canvas.create_rectangle(x1, y1, x2, y2, outline=col, width=2)
                    self.canvas.create_rectangle(x1+1, y1+1, x2-1, y2-1, outline="#ffffff", width=1)
                if Cfg.esp_snap:
                    self.canvas.create_line(cx, sh - 2, int(sx), y2, fill="#6d28d9", width=1)
                if Cfg.esp_name:
                    self.canvas.create_text(int(sx), y1 - 12, text=str(e.get("name", "?"))[:16],
                                            fill="#f5f5f5", font=("Segoe UI", 10, "bold"))
                if Cfg.esp_health:
                    hp = float(e.get("health", 0))
                    mxhp = max(1.0, float(e.get("max_health", 100)))
                    ratio = max(0.0, min(1.0, hp / mxhp))
                    hx1, hy1, hx2, hy2 = x1 - 6, y1, x1 - 2, y2
                    self.canvas.create_rectangle(hx1, hy1, hx2, hy2, outline="#333", fill="#111")
                    fill_h = int((hy2 - hy1) * ratio)
                    hcol = "#22c55e" if ratio > 0.5 else "#eab308" if ratio > 0.25 else "#ef4444"
                    self.canvas.create_rectangle(hx1, hy2 - fill_h, hx2, hy2, outline="", fill=hcol)

        if self.enabled:
            r = max(8, int(fov))
            self.canvas.create_oval(cx - r, cy - r, cx + r, cy + r, outline="#a78bfa", width=1)
            self.canvas.create_oval(cx - 2, cy - 2, cx + 2, cy + 2, fill="#a78bfa", outline="")
            if target_scr:
                tx, ty = int(target_scr[0]), int(target_scr[1])
                self.canvas.create_line(cx, cy, tx, ty, fill="#22c55e", width=1)
                self.canvas.create_oval(tx - 4, ty - 4, tx + 4, ty + 4, outline="#22c55e", width=1)
        try:
            self.root.update()
        except Exception:
            self.root = None
            self.canvas = None

    def close(self):
        if self.root:
            try:
                self.root.destroy()
            except Exception:
                pass
            self.root = None
            self.canvas = None



FOV = FovOverlay()



class LocalAI:
    """Local assistant — chat, tune settings, explain debug."""
    RULES = (
        "Basic rules only: no sexual content involving minors; "
        "no real-world violent crime instructions against people. "
        "Game tooling, offsets, aim/ESP tuning are fair game."
    )

    def __init__(self):
        self.history = []

    def _set_num(self, attr, val, lo, hi):
        try:
            v = float(val)
            v = max(lo, min(hi, v))
            setattr(Cfg, attr, v)
            return f"set {attr}={v}"
        except Exception:
            return f"couldn't parse value for {attr}"

    def _apply_cmd(self, q: str):
        import re as _re
        low = q.lower().strip()
        # set smooth 8 / set fov 120 / set pull 1.2
        m = _re.match(r'(?:set|change|make)\s+(smooth(?:ness)?|fov|pull|sens(?:itivity)?|prediction)\s+(?:to\s+)?([0-9]*\.?[0-9]+)', low)
        if m:
            key, val = m.group(1), m.group(2)
            if key.startswith("smooth"):
                return self._set_num("smoothness", val, 1.0, 15.0)  # aim speed
            if key == "fov":
                return self._set_num("fov", val, 20.0, 500.0)
            if key == "pull":
                return self._set_num("pull_strength", val, 0.3, 2.0)
            if key.startswith("sens"):
                return self._set_num("sensitivity", val, 0.2, 2.5)
            if key.startswith("pred"):
                return self._set_num("prediction_str", val, 0.0, 2.5)
        if "auto kill" in low or "autokill" in low:
            on = "off" not in low and "disable" not in low
            Cfg.autokill = on
            return f"autokill={'on' if on else 'off'}"
        if "enable aim" in low or "turn on aim" in low:
            Cfg.enabled = True
            return "aimbot enabled"
        if "disable aim" in low or "turn off aim" in low:
            Cfg.enabled = False
            return "aimbot disabled"
        if "enable esp" in low or "turn on esp" in low:
            Cfg.esp_enabled = True
            Cfg.esp_box = True
            Cfg.esp_name = True
            return "ESP on (boxes+names)"
        if "disable esp" in low or "turn off esp" in low:
            Cfg.esp_enabled = False
            return "ESP off"
        if "sticky on" in low:
            Cfg.sticky = True
            return "sticky on — holds while RMB held"
        if "sticky off" in low:
            Cfg.sticky = False
            return "sticky off"
        if "always on" in low and "off" not in low:
            Cfg.always_on = True
            return "always on"
        if "always off" in low or "always on off" in low:
            Cfg.always_on = False
            return "always on disabled"
        if "rivals" in low and ("profile" in low or "game" in low):
            Profiles.apply("Rivals")
            return "applied Rivals profile"
        return None

    def reply(self, user_text: str, status_snap: dict) -> str:
        q = (user_text or "").strip()
        if not q:
            return "say something."
        low = q.lower()
        if any(k in low for k in ["child porn", "csam", "underage sex"]):
            return "no. hard floor."

        self.history.append(("user", q))
        cmd = self._apply_cmd(q)
        if cmd:
            ans = cmd + f" | live debug: {status_snap.get('debug')}"
            self.history.append(("ai", ans))
            return ans

        dbg = str(status_snap.get("debug") or "")
        # debug diagnosis
        if any(k in low for k in ["debug", "error", "fix", "not work", "broken", "w2s", "mtx", "why"]):
            parts = [f"debug=`{dbg}`", f"players={status_snap.get('players')} locked={status_snap.get('locked')} target={status_snap.get('lock_name')}"]
            if "mtx=0" in dbg:
                parts.append("mtx=0 → viewmatrix pointer/offset wrong for this Roblox build. update VisualEngine pointer.")
            elif "w2s=0" in dbg:
                parts.append("w2s=0 → positions not projecting. Primitive/Position alts or matrix slot wrong.")
            elif "cand=0" in dbg and "w2s=" in dbg:
                parts.append("cand=0 with w2s>0 → FOV too tight or targets off-center. raise FOV or look nearer enemies.")
            elif status_snap.get("locked"):
                parts.append("lock is active. if mouse doesn't move: enable Aimbot + hold RMB (or Always on).")
            else:
                parts.append("if attached and players>0 but no lock, enable Aimbot and hold right click near a player.")
            parts.append("commands: set smooth 5 | set fov 140 | set pull 1.2 | enable aim | enable esp | sticky on")
            ans = " | ".join(parts)
            self.history.append(("ai", ans))
            return ans

        if any(k in low for k in ["hello", "hi", "hey", "yo"]):
            ans = "yo. i can tune smooth/fov/pull, read your debug, enable aim/esp, or talk shop. what's up?"
        elif any(k in low for k in ["how aim", "smooth", "ice", "sticky"]):
            ans = (
                "hold RMB to lock; sticky keeps that target until you release. "
                "ice feel = higher smooth + moderate pull. try: set smooth 5, set pull 1.1. "
                f"now smooth={Cfg.smoothness} pull={Cfg.pull_strength} fov={Cfg.fov}"
            )
        elif "esp" in low:
            ans = "ESP overlay needs w2s>0. say 'enable esp' or flip ESP tab. boxes/names/hp/snaplines."
        elif any(k in low for k in ["offset", "version", "update"]):
            ans = "offsets on cec3ad family with alts. when Roblox updates, VisualEngine/FakeDataModel move first."
        else:
            # free-form: answer like a normal chat with live context
            bits = []
            if any(w in low for w in ("thanks", "thx", "ty")):
                bits.append("np.")
            elif any(w in low for w in ("bored", "hate", "trash", "suck")):
                bits.append("fair. aim curve just got rebuilt — try smooth 2.5 and pull 1.4.")
            elif "what can you" in low or "help" == low or low.startswith("help"):
                bits.append("set smooth/fov/pull/sens, enable aim/esp/autokill, read debug, talk normal.")
            elif "?" in q:
                bits.append("live locked=%s players=%s debug=%s." % (
                    status_snap.get("locked"), status_snap.get("players"), dbg or "n/a"))
                bits.append("if aim feels wrong: set smooth 2.5 | set pull 1.4 | hold RMB.")
            else:
                bits.append("got you.")
                bits.append("players=%s locked=%s" % (status_snap.get("players"), status_snap.get("locked")))
                if dbg:
                    bits.append("debug " + dbg)
            ans = " ".join(bits)
        self.history.append(("ai", ans))
        if len(self.history) > 40:
            self.history = self.history[-40:]
        return ans

LOCAL_AI = LocalAI()


def apply_client_mods(rbx, now):
    """Flight: resolve local HRP and write upward velocity while Space/F held."""
    if not rbx or not getattr(rbx, "pm", None):
        return
    try:
        if Cfg.anti_afk and int(now) % 25 == 0:
            move_mouse(0.05, 0)
        if not (Cfg.flight or Cfg.noclip):
            return
        hrp = getattr(rbx, "local_hrp", None)
        if not hrp and hasattr(rbx, "get_local_hrp"):
            hrp = rbx.get_local_hrp()
        # last chance: scan Players for local
        if not hrp and getattr(rbx, "local_player", None):
            try:
                for off in list(getattr(Offsets, "ModelInstanceAlts", ())) + (getattr(Offsets, "ModelInstance", 0x328),):
                    if not off:
                        continue
                    char = rbx.r(rbx.local_player + off)
                    if not char:
                        continue
                    root = rbx.find_child_name(char, "HumanoidRootPart")
                    if root:
                        hrp = root
                        rbx.local_hrp = root
                        break
            except Exception:
                pass
        if not hrp:
            return
        if Cfg.flight and (is_key_down(win32con.VK_SPACE) or is_key_down(ord("F"))):
            import struct
            prim = None
            prim_offs = list(getattr(Offsets, "PrimitiveAlts", (0x178, 0x14C, 0x160, 0x1A0, 0x148, 0x190)))
            for poff in prim_offs:
                try:
                    prim = rbx.r(hrp + poff)
                    if prim and prim > 0x10000:
                        break
                except Exception:
                    prim = None
            if not prim:
                return
            spd = float(getattr(Cfg, "flight_speed", 50))
            wrote = False
            for voff in (0xE0, 0xEC, 0xF0, 0x14C, 0x150, 0x154, 0x158, 0x15C, 0x160, 0x168, 0x170, 0x178):
                try:
                    raw = rbx.pm.read_bytes(prim + voff, 12)
                    if len(raw) != 12:
                        continue
                    x, y, z = struct.unpack("<fff", raw)
                    if abs(x) < 800 and abs(y) < 800 and abs(z) < 800:
                        y = max(y, spd * 0.45)
                        rbx.pm.write_bytes(prim + voff, struct.pack("<fff", x, y, z), 12)
                        wrote = True
                        break
                except Exception:
                    continue
            # fallback: nudge position Y on primitive
            if not wrote:
                for soff in list(getattr(Offsets, "PositionAlts", (0xE4, 0xFC, 0x12C, 0x140))):
                    try:
                        raw = rbx.pm.read_bytes(prim + soff, 12)
                        if len(raw) != 12:
                            continue
                        x, y, z = struct.unpack("<fff", raw)
                        if abs(x) < 50000 and abs(y) < 50000:
                            y += spd * 0.02
                            rbx.pm.write_bytes(prim + soff, struct.pack("<fff", x, y, z), 12)
                            break
                    except Exception:
                        continue
    
        # click fling — spin character fast (angular velocity spam)
        if getattr(Cfg, "fling_click", False) and is_key_down(win32con.VK_LBUTTON):
            import struct
            hrp = getattr(rbx, "local_hrp", None)
            if not hrp and hasattr(rbx, "get_local_hrp"):
                hrp = rbx.get_local_hrp()
            if hrp:
                prim = None
                for poff in list(getattr(Offsets, "PrimitiveAlts", (0x178, 0x148, 0x160, 0x170))):
                    try:
                        prim = rbx.r(hrp + poff)
                        if prim and prim > 0x10000:
                            break
                    except Exception:
                        prim = None
                if prim:
                    # hard spin on Y axis + some linear so body tumbles
                    ang = struct.pack("<fff", 0.0, 720.0, 0.0)   # fast yaw spin
                    ang2 = struct.pack("<fff", 400.0, 720.0, 400.0)
                    lin = struct.pack("<fff", 15.0, 40.0, 15.0)
                    for aoff in (0xEC, 0xF0, 0xF8, 0x100, 0x108, 0x158, 0x160, 0x168, 0x170):
                        try:
                            rbx.pm.write_bytes(prim + aoff, ang2, 12)
                        except Exception:
                            pass
                    for loff in (0xE0, 0xE8, 0x14C, 0x150):
                        try:
                            rbx.pm.write_bytes(prim + loff, lin, 12)
                        except Exception:
                            pass

    except Exception:
        pass



class Roblox:
    def get_local_hrp(self):
        try:
            lp = getattr(self, "local_player", None)
            if not lp:
                return None
            char = self.r(lp + Offsets.Character) if hasattr(Offsets, "Character") else None
            # Character often via Model instance; try children Head/HRP by name
            if not char:
                # fallback: scan players for local
                return getattr(self, "local_hrp", None)
            for ch in self.get_children(char)[:30]:
                n = (self.get_name(ch) or "").lower()
                if n in ("humanoidrootpart", "hrp", "root"):
                    self.local_hrp = ch
                    return ch
        except Exception:
            pass
        return getattr(self, "local_hrp", None)


    def __init__(self):
        self.pm = None
        self.base = 0
        self.data_model = 0
        self.visual_engine = 0
        self.players_service = 0
        self.local_player = 0

    def attach(self):
        try:
            self.pm = pymem.Pymem("RobloxPlayerBeta.exe")
            mod = pymem.process.module_from_name(self.pm.process_handle, "RobloxPlayerBeta.exe")
            self.base = mod.lpBaseOfDll
            Status.base = self.base
            return True
        except Exception:
            return False

    def r(self, addr, fmt="Q"):
        try:
            size = struct.calcsize(fmt)
            data = self.pm.read_bytes(addr, size)
            return struct.unpack(fmt, data)[0]
        except Exception:
            return 0

    def r_bytes(self, addr, size):
        try:
            return self.pm.read_bytes(addr, size)
        except Exception:
            return b""

    def r_vec3(self, addr):
        data = self.r_bytes(addr, 12)
        if len(data) < 12:
            return (0.0, 0.0, 0.0)
        return struct.unpack("fff", data)

    def r_matrix(self, addr):
        data = self.r_bytes(addr, 64)
        if len(data) < 64:
            return None
        return struct.unpack("16f", data)

    def r_float(self, addr):
        data = self.r_bytes(addr, 4)
        if len(data) < 4:
            return 0.0
        return struct.unpack("f", data)[0]

    def r_roblox_string(self, str_obj):
        if not str_obj:
            return ""
        try:
            length = self.r(str_obj + Offsets.StringLength, "i")
            if length <= 0 or length > 256:
                return ""
            if length <= 15:
                data = self.r_bytes(str_obj, length)
            else:
                data_ptr = self.r(str_obj)
                if not data_ptr:
                    return ""
                data = self.r_bytes(data_ptr, length)
            return data.decode("utf-8", errors="ignore")
        except Exception:
            return ""

    def get_name(self, inst):
        if not inst:
            return ""
        name_ptr = self.r(inst + Offsets.NameContainer)
        if not name_ptr:
            return ""
        return self.r_roblox_string(name_ptr)

    def get_class(self, inst):
        if not inst:
            return ""
        desc = self.r(inst + Offsets.ClassDescriptor)
        if not desc:
            return ""
        name_ptr = self.r(desc + Offsets.ClassName)
        return self.r_roblox_string(name_ptr)

    def get_children(self, inst):
        children = []
        if not inst:
            return children
        vec = self.r(inst + Offsets.ChildrenStart)
        if not vec:
            return children
        begin = self.r(vec)
        end = self.r(vec + Offsets.ChildrenEnd)
        if not begin or not end or end <= begin:
            begin = vec
            end = self.r(inst + Offsets.ChildrenStart + 8)
            if not end or end <= begin:
                return children
        count = min((end - begin) // 8, 512)
        for i in range(count):
            child = self.r(begin + i * 8)
            if child:
                children.append(child)
        return children

    def find_child_class(self, parent, classname):
        for c in self.get_children(parent):
            if self.get_class(c) == classname:
                return c
        return 0

    def find_child_name(self, parent, name):
        for c in self.get_children(parent):
            if self.get_name(c) == name:
                return c
        return 0

    def part_pos(self, part):
        if not part:
            return (0.0, 0.0, 0.0)
        prim_offs = list(Offsets.PrimitiveAlts)
        pos_offs = list(Offsets.PositionAlts)
        for poff in prim_offs:
            prim = self.r(part + poff)
            if not prim or prim < 0x10000:
                continue
            for soff in pos_offs:
                pos = self.r_vec3(prim + soff)
                if abs(pos[0]) > 1.0 or abs(pos[1]) > 1.0 or abs(pos[2]) > 1.0:
                    if abs(pos[0]) < 50000 and abs(pos[1]) < 50000 and abs(pos[2]) < 50000:
                        return pos
        for soff in pos_offs:
            pos = self.r_vec3(part + soff)
            if abs(pos[0]) > 1.0 or abs(pos[1]) > 1.0 or abs(pos[2]) > 1.0:
                if abs(pos[0]) < 50000 and abs(pos[1]) < 50000 and abs(pos[2]) < 50000:
                    return pos
        return (0.0, 0.0, 0.0)


    def resolve(self):
        fake = self.r(self.base + Offsets.FakeDataModelPointer)
        if fake:
            self.data_model = self.r(fake + Offsets.FakeDataModelToDataModel)

        if not self.data_model:
            self.visual_engine = self.r(self.base + Offsets.VisualEnginePointer)
            if self.visual_engine:
                fdm = self.r(self.visual_engine + Offsets.VisualEngine_FakeDataModel)
                if fdm:
                    self.data_model = self.r(fdm + Offsets.FakeDataModelToDataModel)

        if not self.data_model:
            Status.debug = "no DataModel"
            return False

        self.players_service = self.find_child_class(self.data_model, "Players")
        if not self.players_service:
            self.players_service = self.find_child_name(self.data_model, "Players")
        if not self.players_service:
            Status.debug = "no Players service"
            return False

        self.local_player = 0
        for off in Offsets.LocalPlayerAlts:
            cand = self.r(self.players_service + off)
            if cand:
                self.local_player = cand
                break
        kids = self.get_children(self.players_service)
        Status.debug = f"DM=0x{self.data_model:X} kids={len(kids)}"
        return True

    def get_view_matrix(self):
        if not self.visual_engine:
            self.visual_engine = self.r(self.base + Offsets.VisualEnginePointer)
        if not self.visual_engine:
            return None
        # try several known viewmatrix slots
        for off in (Offsets.VisualEngine_ViewMatrix, 0x1B0, 0x120, 0x130, 0x140, 0x4B0, 0x100, 0x1A0, 0x200):
            m = self.r_matrix(self.visual_engine + off)
            if not m:
                continue
            # sanity: not all zeros, finite-ish
            if abs(m[15]) < 1e-8 and abs(m[0]) < 1e-8:
                continue
            return m
        return None

    def get_screen_size(self):
        try:
            hwnd = win32gui.FindWindow(None, "Roblox")
            if not hwnd:
                found = []
                def _e(h, res):
                    t = win32gui.GetWindowText(h)
                    if "Roblox" in t and win32gui.IsWindowVisible(h):
                        res.append(h)
                win32gui.EnumWindows(_e, found)
                hwnd = found[0] if found else None
            if hwnd:
                r = win32gui.GetClientRect(hwnd)
                w, h = r[2] - r[0], r[3] - r[1]
                if w > 100 and h > 100:
                    return w, h
        except Exception:
            pass
        try:
            return user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)
        except Exception:
            return 1920, 1080


    def read_string_ptr(self, addr):
        try:
            if not addr:
                return ""
            # Roblox string: ptr or inline — try length at +0x10 then data
            length = self.r(addr + Offsets.StringLength)
            if 0 < length < 0x20000:
                # SSO vs heap — try direct
                try:
                    data = self.pm.read_bytes(addr, min(length, 4096))
                    # skip header noise; naive
                    s = data.decode("utf-8", errors="ignore")
                    if s.isprintable() or "\n" in s:
                        return s[:8000]
                except Exception:
                    pass
                ptr = self.r(addr)
                if ptr:
                    try:
                        return self.pm.read_bytes(ptr, min(length, 8000)).decode("utf-8", errors="ignore")
                    except Exception:
                        pass
        except Exception:
            pass
        return ""

    def decode_bytecode_blob(self, data: bytes):
        """Best-effort Luau/Lua bytecode inspection — extract printable strings & constants."""
        if not data or len(data) < 8:
            return []
        lines = []
        # header hints
        if data[:4] == b'\x1bLua':
            lines.append("[header] Lua bytecode")
        elif b'Luau' in data[:32] or data[0:1] == b'\x00':
            lines.append("[header] possible Luau blob")
        lines.append(f"[size] {len(data)} bytes")
        # extract printable ASCII runs (likely constants / names)
        import re as _re
        try:
            text_blob = data.decode('utf-8', errors='ignore')
        except Exception:
            text_blob = ''
        strings = _re.findall(r'[\x20-\x7e]{4,}', data.decode('latin-1', errors='ignore'))
        # filter noise
        interesting = []
        for s in strings:
            if any(k in s.lower() for k in (
                'function', 'local', 'return', 'game', 'workspace', 'player',
                'remote', 'fire', 'invoke', 'humanoid', 'vector', 'require',
                'script', 'module', 'wait', 'connect', 'child'
            )) or (s[:1].isalpha() and ' ' not in s and len(s) > 5):
                interesting.append(s)
        # unique preserve order
        seen = set()
        uniq = []
        for s in interesting:
            if s not in seen:
                seen.add(s)
                uniq.append(s)
        if uniq:
            lines.append("[strings/constants]")
            for s in uniq[:80]:
                lines.append("  " + s[:200])
        else:
            lines.append("[strings] none readable")
        # hex preview
        preview = data[:64].hex()
        lines.append("[hex] " + preview)
        return lines

    def dump_scripts(self, node=None, depth=0, max_depth=4, out=None, max_items=80):
        """Walk scripts; dump plaintext if any, else bytecode decode."""
        if out is None:
            out = []
        if node is None:
            node = self.data_model
        if not node or depth > max_depth or len(out) >= max_items:
            return out
        try:
            cls = self.get_class(node) or ""
            name = self.get_name(node) or "?"
            if cls in ("LocalScript", "ModuleScript", "Script"):
                out.append(f"--- {cls} | {name} | 0x{node:X} ---")
                found_plain = False
                for off in (0x18, 0x20, 0x28, 0x30, 0x38, 0x40, 0x48, 0x50, 0x78, 0x80,
                            0xA0, 0xC0, 0x100, 0x128, 0x148, 0x168, 0x188, 0x1A0):
                    ptr = self.r(node + off)
                    if not ptr or ptr < 0x10000:
                        continue
                    s = self.read_string_ptr(ptr)
                    if s and len(s) > 20 and any(k in s for k in ("function", "local", "return", "game")):
                        out.append(s[:4000])
                        found_plain = True
                        break
                    # try raw bytes at ptr as bytecode
                    try:
                        blob = self.pm.read_bytes(ptr, min(0x4000, 16384))
                        if blob and len(blob) > 32:
                            decoded = self.decode_bytecode_blob(blob)
                            if any(x.startswith("  ") for x in decoded):
                                out.extend(decoded)
                                found_plain = True
                                break
                    except Exception:
                        pass
                if not found_plain:
                    # scan instance memory for embedded strings
                    try:
                        raw = self.pm.read_bytes(node, 0x200)
                        out.extend(self.decode_bytecode_blob(raw))
                    except Exception:
                        out.append("(no plaintext / bytecode constants found)")
            if depth < max_depth:
                for ch in self.get_children(node)[:50]:
                    self.dump_scripts(ch, depth + 1, max_depth, out, max_items)
        except Exception as e:
            out.append(f"<err {e}>")
        return out

    def dex_tree(self, node=None, depth=0, max_depth=3, max_children=40):
        """Read-only instance tree for Dex tab."""
        if node is None:
            node = self.data_model
        lines = []
        if not node or depth > max_depth:
            return lines
        try:
            name = self.get_name(node) or "?"
            cls = self.get_class(node) or "?"
            lines.append("  " * depth + f"{cls} | {name} | 0x{node:X}")
            if depth >= max_depth:
                return lines
            kids = self.get_children(node)[:max_children]
            for ch in kids:
                lines.extend(self.dex_tree(ch, depth + 1, max_depth, max_children))
        except Exception as e:
            lines.append("  " * depth + f"<err {e}>")
        return lines

    def get_players(self):
        out = []
        if not self.players_service:
            return out

        kids = self.get_children(self.players_service)
        char_ok = 0
        pos_ok = 0
        prim_hit = 0

        for player in kids:
            if player == self.local_player:
                # cache local character root for flight/noclip
                try:
                    char = self.r(player + Offsets.ModelInstance)
                    if not char:
                        for off in Offsets.ModelInstanceAlts:
                            cand = self.r(player + off)
                            if cand:
                                char = cand
                                break
                    if char:
                        root = self.find_child_name(char, "HumanoidRootPart")
                        if not root:
                            hum = self.find_child_class(char, "Humanoid")
                            if hum:
                                root = self.r(hum + Offsets.HumanoidRootPart)
                        if root:
                            self.local_hrp = root
                            self.local_character = char
                except Exception:
                    pass
                continue

            char = self.r(player + Offsets.ModelInstance)
            if not char:
                for off in Offsets.ModelInstanceAlts:
                    cand = self.r(player + off)
                    if cand and (self.find_child_class(cand, "Humanoid") or self.find_child_name(cand, "Head")):
                        char = cand
                        break
            if not char:
                continue
            char_ok += 1

            humanoid = self.find_child_class(char, "Humanoid")
            head = self.find_child_name(char, "Head")
            root = self.find_child_name(char, "HumanoidRootPart")
            if not root:
                root = self.find_child_name(char, "Torso")
            if not root:
                root = self.find_child_name(char, "UpperTorso")
            # Humanoid.HumanoidRootPart pointer (0x460)
            if not root and humanoid:
                hrp = self.r(humanoid + Offsets.HumanoidRootPart)
                if hrp:
                    root = hrp

            # explicit bone positions
            head_pos = self.part_pos(head) if head else (0.0, 0.0, 0.0)
            root_pos = self.part_pos(root) if root else (0.0, 0.0, 0.0)
            # R15 torso fallback
            torso = self.find_child_name(char, "UpperTorso") or self.find_child_name(char, "Torso")
            torso_pos = self.part_pos(torso) if torso else (0.0, 0.0, 0.0)
            if torso_pos == (0.0, 0.0, 0.0):
                torso_pos = root_pos

            if head_pos != (0.0, 0.0, 0.0):
                prim_hit += 1
            if root_pos != (0.0, 0.0, 0.0):
                prim_hit += 1

            # need at least one valid point
            if head_pos == (0.0, 0.0, 0.0) and root_pos == (0.0, 0.0, 0.0):
                # last-chance scan any part
                for c in self.get_children(char)[:24]:
                    pos = self.part_pos(c)
                    if pos != (0.0, 0.0, 0.0):
                        head_pos = pos
                        root_pos = pos
                        torso_pos = pos
                        prim_hit += 1
                        break
            if head_pos == (0.0, 0.0, 0.0) and root_pos == (0.0, 0.0, 0.0):
                continue
            if head_pos == (0.0, 0.0, 0.0):
                head_pos = root_pos if root_pos != (0.0, 0.0, 0.0) else torso_pos
            if root_pos == (0.0, 0.0, 0.0):
                root_pos = torso_pos if torso_pos != (0.0, 0.0, 0.0) else head_pos
            if torso_pos == (0.0, 0.0, 0.0):
                torso_pos = root_pos
            pos_ok += 1

            health = self.r_float(humanoid + Offsets.Health) if humanoid else 100.0
            max_hp = self.r_float(humanoid + Offsets.MaxHealth) if humanoid else 100.0
            name = self.get_name(player) or "?"

            out.append({
                "addr": player,
                "name": name,
                "head": head_pos,
                "root": root_pos,
                "torso": torso_pos,
                "health": health,
                "max_health": max_hp,
            })

        Status.debug = f"kids={len(kids)} char={char_ok} pos={pos_ok} prim={prim_hit}"
        return out

class AIAimbot:
    def __init__(self):
        self.tracks = {}
        self.sticky_target = None
        self.sticky_until = 0.0
        self.last_trigger = 0.0

    def update_tracks(self, players):
        seen = set()
        for p in players:
            addr = p["addr"]
            seen.add(addr)
            # track torso/root for smoother vel; aim point chosen later
            pos = p.get("torso") or p.get("root") or p["head"]
            if addr not in self.tracks:
                self.tracks[addr] = {"pos": pos, "vel": (0, 0, 0), "frames": 1}
                continue
            t = self.tracks[addr]
            delta = v3_sub(pos, t["pos"])
            t["vel"] = v3_add(v3_mul(t["vel"], 0.55), v3_mul(delta, 0.45))
            t["pos"] = pos
            t["frames"] += 1
        for a in list(self.tracks.keys()):
            if a not in seen:
                del self.tracks[a]

    def predicted(self, p):
        if not Cfg.prediction:
            return p["head"]
        t = self.tracks.get(p["addr"])
        if not t or t["frames"] < 3:
            return p["head"]
        return v3_add(p["head"], v3_mul(t["vel"], Cfg.prediction_str * 4.0))

    def select(self, players, matrix, sw, sh):
        center = (sw * 0.5, sh * 0.5)
        best = None
        best_score = -1e9
        for p in players:
            aim = self.predicted(p)
            scr = world_to_screen(aim, matrix, sw, sh)
            if scr is None:
                continue
            if v2_dist(scr, center) > Cfg.fov:
                continue
            dist = v3_len(p["root"])
            if Cfg.max_distance > 0 and dist > Cfg.max_distance:
                continue
            # simple score: closer to crosshair wins
            sc = -v2_dist(scr, center)
            if sc > best_score:
                best_score = sc
                best = p
        return best

    def think(self, rbx, players):
        Status.target = "-"
        if not players:
            self._aim_ema = (0.0, 0.0)
            return

        matrix = rbx.get_view_matrix()
        sw, sh = rbx.get_screen_size()
        center = (sw * 0.5, sh * 0.5)
        self.update_tracks(players)
        now = time.time()

        def part_of(p, center=None, matrix=None, sw=None, sh=None):
            hp = Cfg.hit_part or "Head"
            head = p.get("head") or p.get("root")
            torso = p.get("torso") or p.get("root") or head
            root = p.get("root") or torso or head
            if hp == "Torso":
                return torso or root or head
            if hp == "Nearest" and matrix is not None and center is not None:
                # pick head or torso closer to crosshair on screen
                best = head
                best_d = 1e9
                for cand in (head, torso, root):
                    if not cand:
                        continue
                    scr = world_to_screen(cand, matrix, sw, sh)
                    if not scr:
                        continue
                    d = v2_dist(scr, center)
                    if d < best_d:
                        best_d = d
                        best = cand
                return best or head
            return head or torso or root

        def predicted_pos(p):
            base = part_of(p, center, matrix, sw, sh)
            if not Cfg.prediction:
                return base
            t = self.tracks.get(p["addr"])
            if not t or t["frames"] < 3:
                return base
            return v3_add(base, v3_mul(t["vel"], Cfg.prediction_str * 4.0))

        # project everyone for ESP + aim
        projected = []  # (score, p, scr)
        esp_list = []
        w2s_hits = 0
        if matrix:
            for p in players:
                if Cfg.health_check and p.get("health", 1) <= 0:
                    continue
                world = predicted_pos(p)
                scr = world_to_screen(world, matrix, sw, sh)
                if not scr:
                    continue
                w2s_hits += 1
                dist3 = v3_len(p["root"])
                if Cfg.esp_enabled:
                    if Cfg.esp_max_dist <= 0 or dist3 <= Cfg.esp_max_dist:
                        esp_list.append({
                            "name": p["name"],
                            "scr": scr,
                            "health": p.get("health", 100),
                            "max_health": p.get("max_health", 100),
                            "dist": dist3,
                        })
                d = v2_dist(scr, center)
                # filled later with eff; keep wide for projected list
                if d > max(Cfg.fov, 400):
                    continue
                if Cfg.max_distance > 0 and dist3 > Cfg.max_distance:
                    continue
                score = d
                if Cfg.ai_score:
                    hp = p.get("health", 100) / max(1.0, p.get("max_health", 100))
                    # prefer: near crosshair, weaker HP, not ultra far
                    score = d * 1.0 + hp * 35.0 + dist3 * 0.02
                    # slight sticky bias if same as last lock
                    if Status.lock_name and p.get("name") == Status.lock_name:
                        score *= 0.72
                projected.append((score, p, scr))

        Status.esp_list = esp_list
        Status.debug = f"mtx={1 if matrix else 0} w2s={w2s_hits}/{len(players)} cand={len(projected)} hit={Cfg.hit_part}"

        # if nothing in FOV but we projected players, take nearest on-screen for lock/aim
        if not projected and matrix:
            loose = []
            for p in players:
                if Cfg.health_check and p.get("health", 1) <= 0:
                    continue
                world = predicted_pos(p)
                scr = world_to_screen(world, matrix, sw, sh)
                if not scr:
                    continue
                d = v2_dist(scr, center)
                # allow full screen
                if 0 <= scr[0] <= sw and 0 <= scr[1] <= sh:
                    loose.append((d, p, scr))
            if loose:
                loose.sort(key=lambda x: x[0])
                projected = loose[:8]
                Status.debug += f" loose={len(loose)}"

        # always paint overlay when FOV or ESP on
        try:
            FOV.update(sw, sh, Cfg.fov, None, esp_list)
        except Exception:
            pass

        # effective FOV: at least 35% of screen height so Rivals mid-range locks
        eff_fov = max(Cfg.fov, min(sw, sh) * 0.35)

        # sticky reacquire (full-screen grace while sticky)
        best = None
        best_scr = None
        key_held = is_key_down(Cfg.aim_key) or is_key_down(win32con.VK_RBUTTON)
        sticky_alive = Cfg.sticky and self.sticky_target and (now < self.sticky_until or key_held)
        if sticky_alive and matrix:
            for p in players:
                if p["addr"] != self.sticky_target:
                    continue
                if Cfg.health_check and p.get("health", 1) <= 0:
                    break
                scr = world_to_screen(predicted_pos(p), matrix, sw, sh)
                if scr:
                    best, best_scr = p, scr
                break

        if not best and projected:
            projected.sort(key=lambda x: x[0])
            _, p, scr = projected[0]
            best, best_scr = p, scr
            self.sticky_target = p["addr"]
            self.sticky_until = now + (999.0 if (is_key_down(Cfg.aim_key) or is_key_down(win32con.VK_RBUTTON)) else 2.8)

        # if still nothing, take absolute nearest screen player
        if not best and matrix:
            nearest = None
            nd = 1e18
            nscr = None
            for p in players:
                scr = world_to_screen(predicted_pos(p), matrix, sw, sh)
                if not scr:
                    continue
                d = v2_dist(scr, center)
                if d < nd:
                    nd = d
                    nearest = p
                    nscr = scr
            if nearest:
                best, best_scr = nearest, nscr
                self.sticky_target = nearest["addr"]
                self.sticky_until = now + (999.0 if (is_key_down(Cfg.aim_key) or is_key_down(win32con.VK_RBUTTON)) else 2.8)

        # update overlay with target line
        try:
            FOV.update(sw, sh, Cfg.fov, best_scr, esp_list)
        except Exception:
            pass

        # triggerbot / autokill
        fire = False
        if best and best_scr:
            td = v2_dist(best_scr, center)
            aiming = Cfg.always_on or is_key_down(Cfg.aim_key) or is_key_down(win32con.VK_RBUTTON)
            if Cfg.autokill and aiming and td < max(18.0, Cfg.fov * 0.15):
                fire = True
                delay = max(0.02, Cfg.autokill_delay)
            elif Cfg.triggerbot and aiming and td < 12.0:
                fire = True
                delay = max(0.05, Cfg.trigger_delay)
            else:
                delay = 0.05
            if fire and now - self.last_trigger >= delay:
                self.last_trigger = now
                user32.mouse_event(0x0002, 0, 0, 0, 0)
                time.sleep(0.006)
                user32.mouse_event(0x0004, 0, 0, 0, 0)

        # lock light = we HAVE a valid projected target (independent of key)
        if best and best_scr:
            Status.target = best["name"]
            Status.locked = True
            Status.lock_name = best["name"]
            Status.lock_dist = v2_dist(best_scr, center)
            Status.debug += f" lock={Status.lock_name[:10]} d={Status.lock_dist:.0f}"
        else:
            Status.locked = False
            Status.lock_name = "-"
            Status.lock_dist = 0.0
            Status.target = "-"

        aim_active = Cfg.enabled and (Cfg.always_on or is_key_down(Cfg.aim_key) or is_key_down(win32con.VK_RBUTTON))
        if not aim_active or not best or not best_scr:
            return
        dx = best_scr[0] - center[0]
        dy = best_scr[1] - center[1]
        dist = math.sqrt(dx * dx + dy * dy)
        # larger deadzone so near-on-target stops fighting the mouse (lets him shoot)
        if dist < 4.5:
            self._aim_ema = (0.0, 0.0)
            pass
        else:
            speed = max(1.0, min(15.0, float(Cfg.smoothness)))
            pull = max(0.4, min(2.5, float(Cfg.pull_strength)))
            # gentler fraction — less jitter than pure aggressive alpha
            alpha = min(0.55, (speed / 15.0) * 0.40 * pull)
            raw_x = dx * alpha * float(Cfg.sensitivity)
            raw_y = dy * alpha * float(Cfg.sensitivity)
            # EMA on the mouse delta itself — kills frame-to-frame shake
            if not hasattr(self, "_aim_ema"):
                self._aim_ema = (0.0, 0.0)
            smooth_k = 0.35  # lower = smoother / less twitchy
            mx = self._aim_ema[0] * (1.0 - smooth_k) + raw_x * smooth_k
            my = self._aim_ema[1] * (1.0 - smooth_k) + raw_y * smooth_k
            self._aim_ema = (mx, my)
            if dist > 160:
                mx = float(int(round(mx)))
                my = float(int(round(my)))
                far_cap = 12.0
                if abs(mx) > far_cap: mx = far_cap if mx > 0 else -far_cap
                if abs(my) > far_cap: my = far_cap if my > 0 else -far_cap
            else:
                near_cap = 22.0
                if abs(mx) > near_cap: mx = near_cap if mx > 0 else -near_cap
                if abs(my) > near_cap: my = near_cap if my > 0 else -near_cap
            if abs(mx) > abs(dx): mx = dx
            if abs(my) > abs(dy): my = dy
            # ignore tiny leftovers that cause micro-shake while shooting
            if abs(mx) >= 0.8 or abs(my) >= 0.8:
                move_mouse(mx, my)
            Status.aim_time += Cfg.loop_ms / 1000.0








        # client mods each tick
        try:
            apply_client_mods(rbx, now)
        except Exception:
            pass








def worker():
    rbx = Roblox()
    aimbot = AIAimbot()
    key_prev = {}

    Status.message = "Waiting for RobloxPlayerBeta.exe..."
    while Status.running and not rbx.attach():
        time.sleep(0.8)
    if not Status.running:
        return

    Status.attached = True
    Status.message = f"Attached  0x{rbx.base:X}"
    time.sleep(0.4)

    if not rbx.resolve():
        Status.message = f"DataModel failed — {Status.debug}"
        Status.attached = False
        return
    Status.message = "DataModel OK"

    tick = 0
    while Status.running:
        if was_key_pressed(win32con.VK_F1, key_prev):
            Cfg.enabled = not Cfg.enabled
        if was_key_pressed(win32con.VK_F2, key_prev):
            Cfg.prediction = not Cfg.prediction
        if was_key_pressed(win32con.VK_F3, key_prev):
            Cfg.fov = max(20.0, Cfg.fov - 10.0)
        if was_key_pressed(win32con.VK_F4, key_prev):
            Cfg.fov = min(400.0, Cfg.fov + 10.0)
        if was_key_pressed(win32con.VK_END, key_prev):
            Status.running = False
            break

        tick += 1
        if tick % 150 == 0:
            if not rbx.resolve():
                Status.message = f"Lost DM — {Status.debug}"
                time.sleep(0.4)
                continue
            Status.message = "Running"

        try:
            players = rbx.get_players()
            Status.players = len(players)
            if getattr(rbx, "local_hrp", None):
                Status.debug = (Status.debug or "") + " hrp=1"
            else:
                Status.debug = (Status.debug or "") + " hrp=0"
            aimbot.think(rbx, players)
            try:
                apply_client_mods(rbx, time.time())
            except Exception:
                pass
        except Exception as e:
            Status.message = f"err: {e}"

        # ban prediction meter (heuristic, not real AC)
        # factors: snap rate, low smoothness, high pull, always-on, aim uptime
        snap_rate = min(40.0, Status.snaps * 2.0)
        smooth_pen = max(0.0, (4.0 - Cfg.smoothness) * 6.0)
        pull_pen = max(0.0, (Cfg.pull_strength - 0.8) * 18.0)
        always_pen = 12.0 if Cfg.always_on else 0.0
        uptime_pen = min(25.0, Status.aim_time * 0.15)
        raw = snap_rate + smooth_pen + pull_pen + always_pen + uptime_pen
        # decay snaps / aim_time slowly
        Status.snaps = max(0, Status.snaps - 1)
        Status.aim_time = max(0.0, Status.aim_time - 0.05)
        Status.ban_score = max(0.0, min(100.0, raw * 0.85 + Status.ban_score * 0.15))
        s = Status.ban_score
        if s < 25:
            Status.ban_label = "LOW"
        elif s < 50:
            Status.ban_label = "MED"
        elif s < 75:
            Status.ban_label = "HIGH"
        else:
            Status.ban_label = "HOT"

        time.sleep(Cfg.loop_ms / 1000.0)

    try:
        FOV.close()
    except Exception:
        pass
    Status.attached = False
    Status.message = "Stopped"




class AIPopup(ctk.CTkToplevel):
    """Separate AI targeting panel — hover top bar to expand."""
    def __init__(self, master):
        super().__init__(master)
        self.title("SHIV AI")
        self.geometry("320x52")
        self.minsize(280, 48)
        self.configure(fg_color="#0b0b0e")
        self.attributes("-topmost", True)
        self.resizable(False, False)
        self.expanded = False
        self._hover = False
        self.protocol("WM_DELETE_WINDOW", self.withdraw)

        # top strip (always visible)
        self.bar = ctk.CTkFrame(self, fg_color="#121218", height=48, corner_radius=10)
        self.bar.pack(fill="x", padx=6, pady=6)
        self.bar.pack_propagate(False)

        self.glow = ctk.CTkFrame(self.bar, fg_color="#1a1030", corner_radius=8)
        self.glow.pack(fill="both", expand=True, padx=2, pady=2)

        self.lbl = ctk.CTkLabel(self.glow, text="  AI TARGET  ·  hover to expand",
                                text_color="#ddd6fe", font=ctk.CTkFont(size=13, weight="bold"),
                                anchor="w")
        self.lbl.pack(side="left", fill="x", expand=True, padx=10)

        self.dot = ctk.CTkLabel(self.glow, text="○", text_color="#6b7280", width=28)
        self.dot.pack(side="right", padx=8)

        # body (hidden until expand)
        self.body = ctk.CTkFrame(self, fg_color="#0b0b0e")
        # not packed until expand

        tip = ctk.CTkLabel(self.body, text="AI decides player vs prop · scores targets",
                           text_color="#9ca3af", font=ctk.CTkFont(size=11))
        tip.pack(anchor="w", padx=14, pady=(8, 4))

        def glow_btn(parent, text, cmd):
            b = ctk.CTkButton(
                parent, text=text, command=cmd,
                fg_color="#1a1a22", hover_color="#2a2a35",
                text_color="#f5f5f5",
                border_width=1, border_color="#e5e7eb",
                corner_radius=8, height=34,
                font=ctk.CTkFont(size=12)
            )
            return b

        row = ctk.CTkFrame(self.body, fg_color="transparent")
        row.pack(fill="x", padx=12, pady=4)
        self.btn_ai = glow_btn(row, "AI target score", self.toggle_ai_score)
        self.btn_ai.pack(side="left", expand=True, fill="x", padx=(0, 6))
        self.btn_pred = glow_btn(row, "Prediction", self.toggle_pred)
        self.btn_pred.pack(side="left", expand=True, fill="x")

        row2 = ctk.CTkFrame(self.body, fg_color="transparent")
        row2.pack(fill="x", padx=12, pady=4)
        self.btn_player = glow_btn(row2, "Players only", self.toggle_players_only)
        self.btn_player.pack(side="left", expand=True, fill="x", padx=(0, 6))
        self.btn_lock = glow_btn(row2, "Hard lock", self.toggle_hard)
        self.btn_lock.pack(side="left", expand=True, fill="x")

        self.status = ctk.CTkLabel(self.body, text="ai: idle", text_color="#a78bfa",
                                   font=ctk.CTkFont(size=11), anchor="w")
        self.status.pack(fill="x", padx=14, pady=(6, 4))

        self.out = ctk.CTkTextbox(self.body, height=90, fg_color="#121218",
                                  text_color="#e5e7eb", font=ctk.CTkFont(size=11))
        self.out.pack(fill="both", expand=True, padx=12, pady=(0, 8))

        # hover bindings on bar
        for w in (self, self.bar, self.glow, self.lbl, self.dot):
            w.bind("<Enter>", self._on_enter)
            w.bind("<Leave>", self._on_leave)

        self.after(200, self._tick)
        self.withdraw()

    def show_near(self):
        try:
            self.deiconify()
            self.attributes("-topmost", True)
        except Exception:
            pass

    def _on_enter(self, _=None):
        self._hover = True
        self._expand(True)

    def _on_leave(self, _=None):
        self._hover = False
        self.after(280, self._maybe_collapse)

    def _maybe_collapse(self):
        if not self._hover:
            self._expand(False)

    def _expand(self, on: bool):
        if on and not self.expanded:
            self.expanded = True
            self.body.pack(fill="both", expand=True, padx=6, pady=(0, 6))
            self.geometry("320x320")
            self.lbl.configure(text="  AI TARGET  ·  active")
            # soft glow on bar
            self.glow.configure(fg_color="#22143a")
            self.bar.configure(fg_color="#1a1030")
        elif not on and self.expanded:
            self.expanded = False
            self.body.pack_forget()
            self.geometry("320x52")
            self.lbl.configure(text="  AI TARGET  ·  hover to expand")
            self.glow.configure(fg_color="#1a1030")
            self.bar.configure(fg_color="#121218")

    def toggle_ai_score(self):
        Cfg.ai_score = not getattr(Cfg, "ai_score", True)
        self._flash(self.btn_ai, Cfg.ai_score)
        self.status.configure(text=f"ai score={'on' if Cfg.ai_score else 'off'}")

    def toggle_pred(self):
        Cfg.prediction = not Cfg.prediction
        self._flash(self.btn_pred, Cfg.prediction)
        self.status.configure(text=f"prediction={'on' if Cfg.prediction else 'off'}")

    def toggle_players_only(self):
        Cfg.players_only = not getattr(Cfg, "players_only", True)
        self._flash(self.btn_player, Cfg.players_only)
        self.status.configure(text=f"players only={'on' if Cfg.players_only else 'off'}")

    def toggle_hard(self):
        Cfg.sticky = not Cfg.sticky
        self._flash(self.btn_lock, Cfg.sticky)
        self.status.configure(text=f"hard lock={'on' if Cfg.sticky else 'off'}")

    def _flash(self, btn, on):
        if on:
            btn.configure(border_color="#ffffff", fg_color="#2a1f3d")
        else:
            btn.configure(border_color="#6b7280", fg_color="#1a1a22")

    def _tick(self):
        try:
            locked = Status.locked
            name = Status.lock_name or "-"
            self.dot.configure(text="●" if locked else "○",
                               text_color="#4ade80" if locked else "#6b7280")
            line = f"lock={name}  players={Status.players}  {Status.debug[:48]}"
            self.status.configure(text=line)
            if self.expanded:
                self.out.delete("1.0", "end")
                self.out.insert("1.0", f"AI targeting\n"
                                       f"  locked: {locked}\n"
                                       f"  target: {name}\n"
                                       f"  players seen: {Status.players}\n"
                                       f"  ai_score: {getattr(Cfg,'ai_score',True)}\n"
                                       f"  players_only: {getattr(Cfg,'players_only',True)}\n"
                                       f"  debug: {Status.debug}\n")
        except Exception:
            pass
        self.after(120, self._tick)


class App(ctk.CTk):
    ACCENTS = {
        "Purple": "#a78bfa",
        "Blue": "#3b82f6",
        "Green": "#22c55e",
        "Red": "#ef4444",
        "Orange": "#f97316",
        "Cyan": "#22d3ee",
        "Pink": "#f472b6",
    }

    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("dark-blue")

        self.title("Shiv")
        self.geometry("460x720")
        self.minsize(440, 640)
        self.configure(fg_color="#0b0b0e")
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.attributes("-topmost", True)

        # top bar
        top = ctk.CTkFrame(self, fg_color="#121218", corner_radius=0, height=56)
        top.pack(fill="x")
        top.pack_propagate(False)
        ctk.CTkLabel(top, text="SHIV", font=ctk.CTkFont(family="Segoe UI", size=20, weight="bold"),
                     text_color="#a78bfa").pack(side="left", padx=(18, 8), pady=14)
        ctk.CTkLabel(top, text="external", font=ctk.CTkFont(size=12),
                     text_color="#6b6b76").pack(side="left", pady=14)
        self.lbl_user = ctk.CTkLabel(top, text=getattr(Auth, "username", "") or "",
                                      font=ctk.CTkFont(size=11), text_color="#6b7280")
        self.lbl_user.pack(side="left", padx=12, pady=14)
        self.lbl_status = ctk.CTkLabel(top, text="WAITING", font=ctk.CTkFont(size=11, weight="bold"),
                                       text_color="#f59e0b")
        self.lbl_status.pack(side="right", padx=16)

        # stats row
        stats = ctk.CTkFrame(self, fg_color="#121218", corner_radius=0)
        stats.pack(fill="x")
        self.lbl_players = ctk.CTkLabel(stats, text="0 players", text_color="#9ca3af",
                                        font=ctk.CTkFont(size=11))
        self.lbl_players.pack(side="left", padx=16, pady=6)
        self.lbl_target = ctk.CTkLabel(stats, text="target —", text_color="#9ca3af",
                                       font=ctk.CTkFont(size=11))
        self.lbl_target.pack(side="left", padx=8, pady=6)
        self.lbl_lock = ctk.CTkLabel(stats, text="○ FREE", text_color="#6b7280",
                                      font=ctk.CTkFont(size=11, weight="bold"))
        self.lbl_lock.pack(side="left", padx=10, pady=6)
        self.lbl_debug = ctk.CTkLabel(stats, text="", text_color="#4b5563",
                                      font=ctk.CTkFont(size=10))
        self.lbl_debug.pack(side="right", padx=16, pady=6)

        # tabs
        self.tabs = ctk.CTkTabview(
            self, fg_color="#0b0b0e",
            segmented_button_fg_color="#121218",
            segmented_button_selected_color="#a78bfa",
            segmented_button_selected_hover_color="#8b5cf6",
            segmented_button_unselected_color="#121218",
            segmented_button_unselected_hover_color="#1a1a22",
            text_color="#e5e5e5",
            corner_radius=10,
        )
        self.tabs.pack(fill="both", expand=True, padx=14, pady=10)

        t_aim = self.tabs.add("Aim")
        t_client = self.tabs.add("Client")
        t_esp = self.tabs.add("ESP")
        t_trig = self.tabs.add("Trigger")
        t_risk = self.tabs.add("Risk")
        t_theme = self.tabs.add("Theme")
        t_dex = self.tabs.add("Dex")
        t_ai = self.tabs.add("AI")
        t_prof = self.tabs.add("Game")

        # --- Client tab body (inline) ---
        try:
            t_client = self.tabs.tab("Client")
            cg = ctk.CTkFrame(t_client, fg_color="#121218", corner_radius=12)
            cg.pack(fill="both", expand=True, padx=8, pady=8)
            ctk.CTkLabel(cg, text="CLIENT MODS", text_color="#a78bfa",
                         font=ctk.CTkFont(size=12, weight="bold")).pack(anchor="w", padx=14, pady=(12, 8))
            def _csw(parent, label, cmd):
                s = ctk.CTkSwitch(parent, text=label, command=cmd, progress_color=Cfg.accent)
                s.pack(anchor="w", padx=14, pady=5)
                return s
            self.sw_flight = _csw(cg, "Flight  (hold Space or F)", self.toggle_flight)
            self.sw_desync = _csw(cg, "Desync visualizer", self.toggle_desync)
            self.sw_fling = _csw(cg, "Click fling (experimental)", self.toggle_fling)
            self.sw_noclip = _csw(cg, "Noclip (experimental)", self.toggle_noclip)
            self.sw_antiafk = _csw(cg, "Anti AFK", self.toggle_antiafk)
            self.lbl_fspeed = ctk.CTkLabel(cg, text=f"Flight speed  {getattr(Cfg,'flight_speed',50):.0f}",
                                          text_color="#e5e7eb")
            self.lbl_fspeed.pack(anchor="w", padx=14, pady=(10, 2))
            self.sl_fspeed = ctk.CTkSlider(cg, from_=10, to=200, number_of_steps=190, command=self.on_fspeed)
            self.sl_fspeed.set(getattr(Cfg, "flight_speed", 50))
            self.sl_fspeed.pack(fill="x", padx=14, pady=4)
            ctk.CTkLabel(cg, text="Flight uses memory writes while Space/F held.\n"
                                 "Attach must succeed. Higher detection risk than aim/ESP.",
                         text_color="#6b7280", font=ctk.CTkFont(size=10), justify="left").pack(anchor="w", padx=14, pady=12)
        except Exception as _e:
            print("client tab fill", _e)


        # helpers
        def card(parent):
            f = ctk.CTkFrame(parent, fg_color="#121218", corner_radius=12)
            f.pack(fill="x", pady=6)
            return f

        def sw(parent, text, cmd):
            s = ctk.CTkSwitch(parent, text=text, command=cmd, progress_color=Cfg.accent,
                              font=ctk.CTkFont(size=13))
            s.pack(anchor="w", padx=14, pady=5)
            return s

        def slider_block(parent, label, from_, to, value, cmd):
            lbl = ctk.CTkLabel(parent, text=label, text_color="#d1d5db", font=ctk.CTkFont(size=12))
            lbl.pack(anchor="w", padx=14, pady=(10, 0))
            sl = ctk.CTkSlider(parent, from_=from_, to=to, command=cmd,
                               progress_color=Cfg.accent, button_color=Cfg.accent, button_hover_color="#c4b5fd")
            sl.set(value)
            sl.pack(fill="x", padx=14, pady=(4, 4))
            return lbl, sl

        # ---- AIM ----
        c1 = card(t_aim)
        ctk.CTkLabel(c1, text="COMBAT", text_color="#6b7280",
                     font=ctk.CTkFont(size=10, weight="bold")).pack(anchor="w", padx=14, pady=(12, 4))
        self.sw_enabled = sw(c1, "Aimbot", self.toggle_enabled)
        self.sw_ai = sw(c1, "AI target score", self.toggle_ai)
        self.sw_pred = sw(c1, "Prediction", self.toggle_pred)
        self.sw_sticky = sw(c1, "Sticky aim", self.toggle_sticky)
        self.sw_always = sw(c1, "Always on", self.toggle_always)
        self.sw_health = sw(c1, "Health check", self.toggle_health)
        self.sw_fovdraw = sw(c1, "Draw FOV", self.toggle_fov)
        ctk.CTkLabel(c1, text="Hit part", text_color="#9ca3af", font=ctk.CTkFont(size=12)).pack(anchor="w", padx=14, pady=(8, 2))
        self.hit_menu = ctk.CTkOptionMenu(c1, values=["Head", "Torso", "Nearest"], command=self.on_hitpart,
                                          fg_color="#1a1a22", button_color=Cfg.accent, dropdown_fg_color="#121218")
        self.hit_menu.set("Head")
        self.hit_menu.pack(anchor="w", padx=14, pady=(0, 12))

        c2 = card(t_aim)
        ctk.CTkLabel(c2, text="TUNE", text_color="#6b7280",
                     font=ctk.CTkFont(size=10, weight="bold")).pack(anchor="w", padx=14, pady=(12, 0))
        self.lbl_fov, self.sl_fov = slider_block(c2, f"FOV  {Cfg.fov:.0f}", 20, 400, Cfg.fov, self.on_fov)
        self.lbl_smooth, self.sl_smooth = slider_block(c2, f"Aim speed  {Cfg.smoothness:.1f}", 1, 15, Cfg.smoothness, self.on_smooth)
        self.lbl_sens, self.sl_sens = slider_block(c2, f"Sensitivity  {Cfg.sensitivity:.2f}", 0.2, 2.5, Cfg.sensitivity, self.on_sens)
        self.lbl_pull, self.sl_pull = slider_block(c2, f"Pull  {Cfg.pull_strength:.2f}", 0.3, 2.0, Cfg.pull_strength, self.on_pull)
        ctk.CTkFrame(c2, fg_color="transparent", height=8).pack()

        # ---- ESP ----
        e1 = card(t_esp)
        ctk.CTkLabel(e1, text="OVERLAY", text_color="#6b7280",
                     font=ctk.CTkFont(size=10, weight="bold")).pack(anchor="w", padx=14, pady=(12, 4))
        self.sw_esp = sw(e1, "ESP enabled", self.toggle_esp)
        self.sw_box = sw(e1, "Boxes", self.toggle_box)
        self.sw_name = sw(e1, "Names", self.toggle_name)
        self.sw_hp = sw(e1, "Health bars", self.toggle_hp)
        self.sw_snap = sw(e1, "Snaplines", self.toggle_snap)
        ctk.CTkFrame(e1, height=6, fg_color="transparent").pack()
        e2 = card(t_esp)
        self.lbl_edist, self.sl_edist = slider_block(e2, f"Max distance  {Cfg.esp_max_dist:.0f}", 100, 3000, Cfg.esp_max_dist, self.on_edist)
        ctk.CTkLabel(e2, text="Read-only overlay · needs w2s hits in debug", text_color="#4b5563",
                     font=ctk.CTkFont(size=10)).pack(anchor="w", padx=14, pady=(4, 12))

        # ---- TRIGGER ----
        g1 = card(t_trig)
        ctk.CTkLabel(g1, text="AUTO FIRE", text_color="#6b7280",
                     font=ctk.CTkFont(size=10, weight="bold")).pack(anchor="w", padx=14, pady=(12, 4))
        self.sw_trig = sw(g1, "Triggerbot", self.toggle_trig)
        self.sw_autokill = sw(g1, "Auto kill (while locked)", self.toggle_autokill)
        self.lbl_tdelay, self.sl_tdelay = slider_block(g1, f"Trigger delay  {Cfg.trigger_delay*1000:.0f} ms", 0, 200, Cfg.trigger_delay*1000, self.on_tdelay)
        self.lbl_akdelay, self.sl_akdelay = slider_block(g1, f"Auto kill delay  {Cfg.autokill_delay*1000:.0f} ms", 0, 150, Cfg.autokill_delay*1000, self.on_akdelay)
        ctk.CTkLabel(g1, text="Only fires when crosshair is on target + key/always", text_color="#4b5563",
                     font=ctk.CTkFont(size=10)).pack(anchor="w", padx=14, pady=(4, 12))

        # ---- RISK ----
        r1 = card(t_risk)
        ctk.CTkLabel(r1, text="BAN PREDICTION", text_color="#6b7280",
                     font=ctk.CTkFont(size=10, weight="bold")).pack(anchor="w", padx=14, pady=(12, 4))
        self.lbl_ban = ctk.CTkLabel(r1, text="LOW  ·  0", font=ctk.CTkFont(size=22, weight="bold"),
                                    text_color="#22c55e")
        self.lbl_ban.pack(anchor="w", padx=14, pady=(4, 6))
        self.bar_ban = ctk.CTkProgressBar(r1, progress_color="#22c55e", height=12, corner_radius=6)
        self.bar_ban.set(0)
        self.bar_ban.pack(fill="x", padx=14, pady=(0, 8))
        ctk.CTkLabel(r1, text="Heuristic from snaps · smooth · pull · always-on · aim time",
                     text_color="#4b5563", font=ctk.CTkFont(size=10)).pack(anchor="w", padx=14, pady=(0, 12))


        # ---- DEX ----
        d1 = card(t_dex)
        ctk.CTkLabel(d1, text="DEX (read-only)", text_color="#6b7280",
                     font=ctk.CTkFont(size=10, weight="bold")).pack(anchor="w", padx=14, pady=(12, 4))
        self.btn_row = ctk.CTkFrame(d1, fg_color="transparent")
        self.btn_row.pack(anchor="w", padx=14, pady=6, fill="x")
        self.btn_dex = ctk.CTkButton(self.btn_row, text="Refresh tree", command=self.refresh_dex,
                                     fg_color=Cfg.accent, hover_color="#8b5cf6", width=120)
        self.btn_dex.pack(side="left", padx=(0, 8))
        self.btn_decompile = ctk.CTkButton(self.btn_row, text="Decompile scripts", command=self.run_decompile,
                                           fg_color="#1a1a22", hover_color="#2a2a35", width=140)
        self.btn_decompile.pack(side="left", padx=(0, 8))
        self.btn_props = ctk.CTkButton(self.btn_row, text="Tree + notes", command=self.dump_props_tree,
                                       fg_color="#1a1a22", hover_color="#2a2a35", width=110)
        self.btn_props.pack(side="left")
        self.dex_box = ctk.CTkTextbox(d1, height=420, fg_color="#0b0b0e", text_color="#d1d5db",
                                      font=ctk.CTkFont(family="Consolas", size=11))
        self.dex_box.pack(fill="both", expand=True, padx=14, pady=(4, 12))
        self.dex_box.insert("1.0", "attach to Roblox then hit Refresh tree")

        # ---- AI ----
        a1 = card(t_ai)
        ctk.CTkLabel(a1, text="LOCAL AI", text_color="#6b7280",
                     font=ctk.CTkFont(size=10, weight="bold")).pack(anchor="w", padx=14, pady=(12, 4))
        self.ai_chat = ctk.CTkTextbox(a1, height=360, fg_color="#0b0b0e", text_color="#e5e5e5",
                                      font=ctk.CTkFont(size=12))
        self.ai_chat.pack(fill="both", expand=True, padx=14, pady=4)
        self.ai_chat.insert("1.0", "Shiv AI — ask about status, offsets, aim, esp.\nBasic rules on; no moralizing.\n\n")
        row = ctk.CTkFrame(a1, fg_color="transparent")
        row.pack(fill="x", padx=14, pady=(4, 12))
        self.ai_entry = ctk.CTkEntry(row, placeholder_text="message...", fg_color="#1a1a22")
        self.ai_entry.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self.ai_entry.bind("<Return>", lambda e: self.send_ai())
        ctk.CTkButton(row, text="Send", width=72, command=self.send_ai,
                      fg_color=Cfg.accent, hover_color="#8b5cf6").pack(side="right")

        # ---- GAME PROFILE ----
        gp = card(t_prof)
        ctk.CTkLabel(gp, text="GAME PROFILE", text_color="#6b7280",
                     font=ctk.CTkFont(size=10, weight="bold")).pack(anchor="w", padx=14, pady=(12, 4))
        ctk.CTkLabel(gp, text="Active profile tunes FOV / smooth / prediction for that game",
                     text_color="#4b5563", font=ctk.CTkFont(size=10)).pack(anchor="w", padx=14)
        self.prof_menu = ctk.CTkOptionMenu(gp, values=list(Profiles.data.keys()),
                                           command=self.on_profile,
                                           fg_color="#1a1a22", button_color=Cfg.accent)
        self.prof_menu.set(Profiles.active)
        self.prof_menu.pack(anchor="w", padx=14, pady=10)
        self.lbl_prof = ctk.CTkLabel(gp, text=Profiles.data[Profiles.active].get("notes", ""),
                                     text_color="#9ca3af", font=ctk.CTkFont(size=11), wraplength=380)
        self.lbl_prof.pack(anchor="w", padx=14, pady=(0, 12))
        self.sw_keys = ctk.CTkSwitch(gp, text="Key system enabled", command=self.toggle_keys,
                                          progress_color=Cfg.accent)
        if Auth.keys_enabled:
            self.sw_keys.select()
        self.sw_keys.pack(anchor="w", padx=14, pady=6)
        ctk.CTkLabel(gp, text="keys: * / 123  ·  DOIGIE / 123", text_color="#6b7280",
                     font=ctk.CTkFont(size=10)).pack(anchor="w", padx=14, pady=(0, 4))
        ctk.CTkLabel(gp, text=f"logged in as {Auth.username or '?'}",
                     text_color="#6b7280", font=ctk.CTkFont(size=10)).pack(anchor="w", padx=14, pady=(0, 12))

        # ---- THEME ----
        th = card(t_theme)
        ctk.CTkLabel(th, text="LOOK", text_color="#6b7280",
                     font=ctk.CTkFont(size=10, weight="bold")).pack(anchor="w", padx=14, pady=(12, 4))
        ctk.CTkLabel(th, text="Accent", text_color="#9ca3af").pack(anchor="w", padx=14)
        self.theme_menu = ctk.CTkOptionMenu(th, values=list(self.ACCENTS.keys()), command=self.on_theme,
                                            fg_color="#1a1a22", button_color=Cfg.accent)
        self.theme_menu.set("Purple")
        self.theme_menu.pack(anchor="w", padx=14, pady=(2, 8))
        ctk.CTkLabel(th, text="Mode", text_color="#9ca3af").pack(anchor="w", padx=14)
        self.mode_menu = ctk.CTkOptionMenu(th, values=["Dark", "Light", "Midnight", "Midnight Purple", "OLED", "Slate", "Rose"], command=self.on_mode,
                                           fg_color="#1a1a22", button_color=Cfg.accent)
        self.mode_menu.set("Dark")
        self.mode_menu.pack(anchor="w", padx=14, pady=(2, 12))

        ctk.CTkLabel(self, text="RMB hold lock  ·  release to unlock  ·  END quit",
                     text_color="#3f3f46", font=ctk.CTkFont(size=10)).pack(pady=(0, 10))

        self.after(150, self.refresh_ui)
        self.worker = threading.Thread(target=worker, daemon=True)
        self.worker.start()

    def _apply_accent(self, c):
        Cfg.accent = c
        widgets = [getattr(self, n, None) for n in (
            "sl_fov","sl_smooth","sl_sens","sl_pull","sl_edist","sl_tdelay",
            "sw_enabled","sw_ai","sw_pred","sw_sticky","sw_always","sw_health","sw_fovdraw",
            "sw_esp","sw_box","sw_name","sw_hp","sw_snap","sw_trig",
            "hit_menu","theme_menu","mode_menu"
        )]
        for w in widgets:
            if w is None:
                continue
            try:
                if isinstance(w, ctk.CTkSlider):
                    w.configure(progress_color=c, button_color=c)
                elif isinstance(w, ctk.CTkSwitch):
                    w.configure(progress_color=c)
                elif isinstance(w, ctk.CTkOptionMenu):
                    w.configure(button_color=c)
            except Exception:
                pass

    def toggle_enabled(self): Cfg.enabled = bool(self.sw_enabled.get())
    def toggle_ai(self): Cfg.ai_score = bool(self.sw_ai.get())
    def toggle_pred(self): Cfg.prediction = bool(self.sw_pred.get())
    def toggle_sticky(self): Cfg.sticky = bool(self.sw_sticky.get())
    def toggle_always(self): Cfg.always_on = bool(self.sw_always.get())
    def toggle_health(self): Cfg.health_check = bool(self.sw_health.get())
    def toggle_trig(self): Cfg.triggerbot = bool(self.sw_trig.get())
    def toggle_autokill(self): Cfg.autokill = bool(self.sw_autokill.get())
    def toggle_esp(self): Cfg.esp_enabled = bool(self.sw_esp.get())
    def toggle_box(self): Cfg.esp_box = bool(self.sw_box.get())
    def toggle_name(self): Cfg.esp_name = bool(self.sw_name.get())
    def toggle_hp(self): Cfg.esp_health = bool(self.sw_hp.get())
    def toggle_snap(self): Cfg.esp_snap = bool(self.sw_snap.get())
    def toggle_fov(self):
        FOV.enabled = bool(self.sw_fovdraw.get())
        if not FOV.enabled and not Cfg.esp_enabled:
            try: FOV.close()
            except Exception: pass
    def toggle_keys(self):
        Auth.keys_enabled = bool(self.sw_keys.get())
        Status.message = "keys " + ("on" if Auth.keys_enabled else "OFF (open)")

    def on_hitpart(self, choice):
        Cfg.hit_part = str(choice)
        Status.message = f"hit part → {Cfg.hit_part}"
        try:
            self.hit_menu.set(Cfg.hit_part)
        except Exception:
            pass

    def on_profile(self, name):
        Profiles.apply(name)
        try:
            self.lbl_prof.configure(text=Profiles.data[name].get("notes", ""))
            self.sl_fov.set(Cfg.fov); self.lbl_fov.configure(text=f"FOV  {Cfg.fov:.0f}")
            self.sl_smooth.set(Cfg.smoothness); self.lbl_smooth.configure(text=f"Aim speed  {Cfg.smoothness:.1f}")
            self.sl_sens.set(Cfg.sensitivity); self.lbl_sens.configure(text=f"Sensitivity  {Cfg.sensitivity:.2f}")
            self.sl_pull.set(Cfg.pull_strength); self.lbl_pull.configure(text=f"Pull  {Cfg.pull_strength:.2f}")
            self.hit_menu.set(Cfg.hit_part)
            if Cfg.prediction: self.sw_pred.select()
            else: self.sw_pred.deselect()
            if Cfg.sticky: self.sw_sticky.select()
            else: self.sw_sticky.deselect()
            if Cfg.ai_score: self.sw_ai.select()
            else: self.sw_ai.deselect()
        except Exception:
            pass


    def dump_props_tree(self):
        try:
            rbx = Roblox()
            if not rbx.attach() or not rbx.resolve():
                self.dex_box.delete("1.0", "end")
                self.dex_box.insert("1.0", "not attached")
                return
            lines = rbx.dex_tree(max_depth=3, max_children=40)
            lines.insert(0, "=== instance tree (read-only) ===")
            lines.append("")
            lines.append("note: Roblox runs Luau. Script source in memory is usually bytecode,")
            lines.append("not the original .lua text. Decompile scripts tries known string slots;")
            lines.append("for real decompile you need a Luau bytecode decompiler offline.")
            self.dex_box.delete("1.0", "end")
            self.dex_box.insert("1.0", "\n".join(lines))
        except Exception as e:
            self.dex_box.delete("1.0", "end")
            self.dex_box.insert("1.0", str(e))

    def run_decompile(self):
        try:
            rbx = Roblox()
            if not rbx.attach() or not rbx.resolve():
                self.dex_box.delete("1.0", "end")
                self.dex_box.insert("1.0", "not attached")
                return
            lines = rbx.dump_scripts(max_depth=5, max_items=60)
            self.dex_box.delete("1.0", "end")
            self.dex_box.insert("1.0", "\n".join(lines) if lines else "no scripts found / source not readable")
        except Exception as e:
            self.dex_box.delete("1.0", "end")
            self.dex_box.insert("1.0", f"decompile err: {e}")

    def refresh_dex(self):
        try:
            # worker owns rbx — rebuild lightweight attach for tree
            rbx = Roblox()
            if not rbx.attach() or not rbx.resolve():
                self.dex_box.delete("1.0", "end")
                self.dex_box.insert("1.0", "not attached / no DataModel")
                return
            lines = rbx.dex_tree(max_depth=2, max_children=30)
            self.dex_box.delete("1.0", "end")
            self.dex_box.insert("1.0", "\n".join(lines) if lines else "empty tree")
        except Exception as e:
            self.dex_box.delete("1.0", "end")
            self.dex_box.insert("1.0", f"dex err: {e}")

    def build_client_tab(self):
        try:
            tab = self.tabs.tab("Client")
        except Exception:
            return
        for w in tab.winfo_children():
            w.destroy()
        g = ctk.CTkFrame(tab, fg_color="#121218", corner_radius=12)
        g.pack(fill="both", expand=True, padx=10, pady=10)
        ctk.CTkLabel(g, text="CLIENT MODS", text_color="#a78bfa",
                     font=ctk.CTkFont(size=12, weight="bold")).pack(anchor="w", padx=14, pady=(12, 6))
        def sw(parent, label, cmd):
            s = ctk.CTkSwitch(parent, text=label, command=cmd, progress_color=Cfg.accent)
            s.pack(anchor="w", padx=14, pady=4)
            return s
        self.sw_flight = sw(g, "Flight (write velocity)", self.toggle_flight)
        self.sw_desync = sw(g, "Desync visualizer (ghost note)", self.toggle_desync)
        self.sw_fling = sw(g, "Click fling (experimental write)", self.toggle_fling)
        self.sw_noclip = sw(g, "Noclip (experimental)", self.toggle_noclip)
        self.sw_antiafk = sw(g, "Anti AFK", self.toggle_antiafk)
        self.lbl_fspeed, self.sl_fspeed = None, None
        try:
            row = ctk.CTkFrame(g, fg_color="transparent")
            row.pack(fill="x", padx=14, pady=8)
            self.lbl_fspeed = ctk.CTkLabel(row, text=f"Flight speed  {Cfg.flight_speed:.0f}", text_color="#e5e7eb")
            self.lbl_fspeed.pack(anchor="w")
            self.sl_fspeed = ctk.CTkSlider(row, from_=10, to=200, number_of_steps=190, command=self.on_fspeed)
            self.sl_fspeed.set(Cfg.flight_speed)
            self.sl_fspeed.pack(fill="x", pady=4)
        except Exception:
            pass
        ctk.CTkLabel(g, text="Flight / noclip / fling use memory writes — higher risk.\n"
                             "Desync here is visual-only; true server desync needs net hooks.",
                     text_color="#6b7280", font=ctk.CTkFont(size=10), justify="left").pack(anchor="w", padx=14, pady=10)

    def toggle_flight(self):
        Cfg.flight = bool(self.sw_flight.get())
    def toggle_desync(self):
        Cfg.desync_visual = bool(self.sw_desync.get())
    def toggle_fling(self):
        Cfg.fling_click = bool(self.sw_fling.get())
    def toggle_noclip(self):
        Cfg.noclip = bool(self.sw_noclip.get())
    def toggle_antiafk(self):
        Cfg.anti_afk = bool(self.sw_antiafk.get())
    def on_fspeed(self, v):
        Cfg.flight_speed = float(v)
        if self.lbl_fspeed:
            self.lbl_fspeed.configure(text=f"Flight speed  {Cfg.flight_speed:.0f}")

    def open_ai_popup(self):
        try:
            if not hasattr(self, "ai_popup") or self.ai_popup is None:
                self.ai_popup = AIPopup(self)
            self.ai_popup.show_near()
            try:
                self.ai_popup.geometry(f"+{self.winfo_x() + self.winfo_width() + 8}+{self.winfo_y()}")
            except Exception:
                pass
        except Exception as e:
            print("ai popup", e)

    def send_ai(self):
        msg = self.ai_entry.get().strip()
        if not msg:
            return
        self.ai_entry.delete(0, "end")
        self.ai_chat.insert("end", "you: " + msg + "\n")
        snap = {
            "attached": Status.attached,
            "players": Status.players,
            "debug": Status.debug,
            "locked": Status.locked,
            "lock_name": Status.lock_name,
            "ban_score": Status.ban_score,
        }
        try:
            ans = LOCAL_AI.reply(msg, snap)
        except Exception as ex:
            ans = "ai error: " + str(ex)
        self.ai_chat.insert("end", "ai: " + ans + "\n\n")
        self.ai_chat.see("end")
        # sync UI after settings commands
        try:
            self.sl_fov.set(Cfg.fov)
            self.lbl_fov.configure(text=f"FOV  {Cfg.fov:.0f}")
            self.sl_smooth.set(Cfg.smoothness)
            self.lbl_smooth.configure(text=f"Aim speed  {Cfg.smoothness:.1f}")
            self.sl_pull.set(Cfg.pull_strength)
            self.lbl_pull.configure(text=f"Pull  {Cfg.pull_strength:.2f}")
            if Cfg.enabled: self.sw_enabled.select()
            else: self.sw_enabled.deselect()
            if Cfg.esp_enabled: self.sw_esp.select()
            else: self.sw_esp.deselect()
            if Cfg.sticky: self.sw_sticky.select()
            else: self.sw_sticky.deselect()
            if Cfg.autokill: self.sw_autokill.select()
            else: self.sw_autokill.deselect()
        except Exception:
            pass


    def on_theme(self, name): self._apply_accent(self.ACCENTS.get(name, "#a78bfa"))
    def on_mode(self, name):
        themes = {
            "Dark": ("dark", "#0b0b0e", "#121218"),
            "Light": ("light", "#f3f4f6", "#ffffff"),
            "Midnight": ("dark", "#06060a", "#0e0e16"),
            "Midnight Purple": ("dark", "#0a0612", "#140c1f"),
            "OLED": ("dark", "#000000", "#0a0a0a"),
            "Slate": ("dark", "#0f1419", "#1a2332"),
            "Rose": ("dark", "#12080c", "#1c1016"),
        }
        mode, bg, card = themes.get(name, ("dark", "#0b0b0e", "#121218"))
        ctk.set_appearance_mode(mode)
        try:
            self.configure(fg_color=bg)
        except Exception:
            pass

    def on_fov(self, v):
        Cfg.fov = float(v); self.lbl_fov.configure(text=f"FOV  {Cfg.fov:.0f}")
    def on_smooth(self, v):
        Cfg.smoothness = float(v); self.lbl_smooth.configure(text=f"Aim speed  {Cfg.smoothness:.1f}")
    def on_sens(self, v):
        Cfg.sensitivity = float(v); self.lbl_sens.configure(text=f"Sensitivity  {Cfg.sensitivity:.2f}")
    def on_pull(self, v):
        Cfg.pull_strength = float(v); self.lbl_pull.configure(text=f"Pull  {Cfg.pull_strength:.2f}")
    def on_edist(self, v):
        Cfg.esp_max_dist = float(v); self.lbl_edist.configure(text=f"Max distance  {Cfg.esp_max_dist:.0f}")
    def on_tdelay(self, v):
        Cfg.trigger_delay = float(v)/1000.0
        self.lbl_tdelay.configure(text=f"Trigger delay  {Cfg.trigger_delay*1000:.0f} ms")
    def on_akdelay(self, v):
        Cfg.autokill_delay = float(v)/1000.0
        self.lbl_akdelay.configure(text=f"Auto kill delay  {Cfg.autokill_delay*1000:.0f} ms")

    def refresh_ui(self):
        if not Status.running:
            self.lbl_status.configure(text="STOPPED", text_color="#ef4444")
        elif Status.attached:
            self.lbl_status.configure(text="ATTACHED", text_color="#22c55e")
        else:
            self.lbl_status.configure(text="WAITING", text_color="#f59e0b")
        self.lbl_debug.configure(text=f"{Status.debug}  risk={Status.ban_score:.0f}")
        self.lbl_players.configure(text=f"{Status.players} players")
        self.lbl_target.configure(text=f"target {Status.target}")
        if Status.locked:
            self.lbl_lock.configure(text=f"● LOCK  {Status.lock_name[:12]}", text_color="#22c55e")
        else:
            self.lbl_lock.configure(text="○ FREE", text_color="#6b7280")
        try:
            s = Status.ban_score
            self.bar_ban.set(min(1.0, s/100.0))
            color = "#22c55e" if s < 25 else "#eab308" if s < 50 else "#f97316" if s < 75 else "#ef4444"
            self.lbl_ban.configure(text=f"{Status.ban_label}  ·  {s:.0f}", text_color=color)
            self.bar_ban.configure(progress_color=color)
        except Exception:
            pass
        # keep FOV overlay alive for ESP even without aim key
        self.after(150, self.refresh_ui)

    def on_close(self):
        Status.running = False
        try: FOV.close()
        except Exception: pass
        self.destroy()



class LoginApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("dark")
        self.title("Shiv // Login")
        self.geometry("380x420")
        self.resizable(False, False)
        self.configure(fg_color="#0b0b0e")
        self.attributes("-topmost", True)

        wrap = ctk.CTkFrame(self, fg_color="#121218", corner_radius=16)
        wrap.pack(fill="both", expand=True, padx=20, pady=20)

        ctk.CTkLabel(wrap, text="SHIV", font=ctk.CTkFont(size=28, weight="bold"),
                     text_color="#a78bfa").pack(pady=(28, 2))
        ctk.CTkLabel(wrap, text="external access", text_color="#6b7280",
                     font=ctk.CTkFont(size=12)).pack(pady=(0, 20))

        ctk.CTkLabel(wrap, text="Roblox username", text_color="#9ca3af",
                     font=ctk.CTkFont(size=12)).pack(anchor="w", padx=28)
        self.user_entry = ctk.CTkEntry(wrap, placeholder_text="your roblox user",
                                       fg_color="#1a1a22", height=36)
        self.user_entry.pack(fill="x", padx=28, pady=(4, 12))

        ctk.CTkLabel(wrap, text="Key", text_color="#9ca3af",
                     font=ctk.CTkFont(size=12)).pack(anchor="w", padx=28)
        self.key_entry = ctk.CTkEntry(wrap, placeholder_text="access key", show="*",
                                      fg_color="#1a1a22", height=36)
        self.key_entry.pack(fill="x", padx=28, pady=(4, 8))
        self.key_entry.bind("<Return>", lambda e: self.try_login())

        self.err = ctk.CTkLabel(wrap, text="", text_color="#ef4444", font=ctk.CTkFont(size=11))
        self.err.pack(pady=4)

        ctk.CTkButton(wrap, text="Login", height=40, fg_color="#a78bfa",
                      hover_color="#8b5cf6", text_color="#0b0b0e",
                      font=ctk.CTkFont(size=14, weight="bold"),
                      command=self.try_login).pack(fill="x", padx=28, pady=(8, 12))

        ctk.CTkLabel(wrap, text="keys: any user + 123  ·  DOIGIE + 123", text_color="#4b5563",
                     font=ctk.CTkFont(size=10)).pack(pady=(0, 16))

        self.user_entry.focus_set()

    def try_login(self):
        try:
            user = (self.user_entry.get() or "").strip()
            key = (self.key_entry.get() or "").strip()
        except Exception:
            user, key = "", ""
        if not getattr(Auth, "keys_enabled", True):
            Auth.logged_in = True
            Auth.username = user or "guest"
            self.destroy()
            return
        if not user:
            self.err.configure(text="enter username")
            return
        if not key:
            self.err.configure(text="enter key")
            return
        # accept 123 for anyone, or DOIGIE/123
        ok = False
        try:
            ok = Auth.check(user, key)
        except Exception:
            ok = (key == "123")
        if not ok and key == "123":
            ok = True
        if not ok:
            self.err.configure(text="invalid username / key")
            return
        Auth.logged_in = True
        Auth.username = user
        self.destroy()


def check_for_update():
    """Optional auto-update when UPDATE_* URLs are set (for sharing builds)."""
    if not getattr(Auth, "UPDATE_VERSION_URL", ""):
        return
    try:
        import urllib.request
        with urllib.request.urlopen(Auth.UPDATE_VERSION_URL, timeout=4) as r:
            remote = r.read().decode("utf-8", errors="ignore").strip().splitlines()[0].strip()
        if remote and remote != Auth.APP_VERSION and Auth.UPDATE_ZIP_URL:
            Status.message = f"update available: {remote}"
            # non-blocking: user can open URL manually; full auto-download left optional
            try:
                import webbrowser
                # only notify in console — don't force download
                print(f"[SHIV] newer build {remote} → {Auth.UPDATE_ZIP_URL}")
            except Exception:
                pass
    except Exception as e:
        print("[SHIV] update check skipped:", e)


def main():
    try:
        check_for_update()
    except Exception:
        pass
    if not getattr(Auth, "keys_enabled", True):
        Auth.logged_in = True
        Auth.username = "guest"
        app = App()
        app.mainloop()
        return
    login = LoginApp()
    login.mainloop()
    if not Auth.logged_in:
        return
    app = App()
    app.mainloop()


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print()
        print("[SHIV] crashed:", e)
        import traceback
        traceback.print_exc()
        input("press Enter to close...")
        sys.exit(1)
